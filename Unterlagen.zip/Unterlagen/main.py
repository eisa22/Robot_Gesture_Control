import Gesture_classifier
from Robot_Control import StartUp, handle_input, move_Robot
from pyedo import edo
import time

if __name__ == "__main__":

    myedo = edo("10.42.0.49")  # ('10.42.0.49') #192.168.12.1
    StartUp(myedo)
    print("success")
    time.sleep(1.0)

    while True:
        # Eingabe einlesen
        user_input = input("Type in 1, 2, 3, 4 oder H --> add h for hover position: ")
        # Eingabe verarbeiten
        target_position = handle_input(user_input)
        if target_position is None:
            print("No position received")
            break
        # Perform Robot Control
        move_Robot(target_position)
        time.sleep(2.0)

        # Wait until robot reaches Position
        #wait_until_position_reached(myedo.getJoints(), target_position)