from pyedo import edo
import time


# Positions
home_position = (100, 0, 0, 0, 0, 0, 0, 20)
grid1_position = (100, 21.32, 51.29, 64.62, -5.98, 63.97, 23.75, 70)
grid1_position_hover = (100, 21.32, 45.89, 62.6, -5.67, 71.34, 22.75, 70)
grid2_position = (100, 8.03, 44.45, 77.03, -6.17, 57.04, 10.93, 70)
grid2_position_hover = (100, 8.03, 37.89, 75.1, -5.69, 65.47, 9.93, 70)
grid3_position = (100, -3.54, 44.42, 77.25, -5.74, 55.69, -0.81, 70)
grid3_position_hover = (100, -3.54, 37.78, 74.33, -5.26, 64.22, -1.75, 70)
grid4_position = (100, -15.79, 47.35, 72.27, -4.84, 56.74, -13.66, 70 )
grid4_position_hover = (100, -15.79, 41, 70.32, -4.46, 65.11, -14.44, 47.93, 70)


def StartUp(myedo):
    myedo.init_7Axes()
    print("Init startup")
    time.sleep(5)
    myedo.disengage_std()
    time.sleep(5)
    myedo.calib_axes() # Mandatory in HOME POSITION

def handle_input(choice):
    if choice == '1':
        print("Case 1 - Robot moves to grid 1")
        target_position = grid1_position
    elif choice == '1h':
        print("Case 1h - Robot moves to grid 1 hover")
        target_position = grid1_position_hover
    elif choice == '2':
        print("Case 2 - Robot moves to grid 2")
        target_position = grid2_position
    elif choice == '2h':
        print("Case 2h - Robot moves to grid 2 hover")
        target_position = grid2_position_hover
    elif choice == '3':
        print("Case 3 - Robot moves to grid 3")
        target_position = grid3_position
    elif choice == '3h':
        print("Case 3h - Robot moves to grid 3 hover")
        target_position = grid3_position_hover
    elif choice == '4':
        print("Case 4 - Robot moves to grid 4")
        target_position = grid4_position
    elif choice == '4h':
        print("Case 4h - Robot moves to grid 4 hover")
        target_position = grid4_position_hover
    elif choice == 'H':
        print("Case H - Robot moves to home")
        target_position = home_position
    else:
        print("Invalid input. Please enter 1, 2, 3, 4 or H + h for hovering.")
    return target_position

def move_Robot(target_position):
    myedo.move_joint(*target_position)
    return True


def wait_until_position_reached(current_position, target_position):
    while True:
        # If the current position is the same as the target position, break the loop
        if current_position == target_position:
            print("Target Position reached!")
            break
        # Otherwise, wait for a short period before checking again
        time.sleep(0.1)
    return True




if __name__ == "__main__":

    myedo = edo("10.42.0.49")  # ('10.42.0.49') #192.168.12.1
    StartUp(myedo)
    print("success")
    time.sleep(1.0)


    while True:
        # Eingabe einlesen
        user_input = input("Type in 1, 2, 3, 4 oder H --> add h for hover position: ")
        # Eingabe verarbeiten
        target_position = handle_input(user_input)
        if target_position is None:
            print("No position received")
            break
        # Perform Robot Control
        move_Robot(target_position)
        time.sleep(2.0)

        # Wait until robot reaches Position
        #wait_until_position_reached(myedo.getJoints(), target_position)


