from Gesture_classifier import HandStateDetector
from Robot_Control import StartUp, handle_input, move_Robot
from pyedo import edo
import time
import keyboard
import Positions

# Global flag to bring robot to home Position when pressing R key
emergancy_stop_off = True  # Start with printing enabled

Positions = Positions()
def on_r_key():
    global emergancy_stop
    emergancy_stop = not emergancy_stop  # Toggle the flag when 'R' is pressed

if __name__ == "__main__":
    handstate_detector = HandStateDetector()

    myedo = edo("10.42.0.49")  # ('10.42.0.49') #192.168.12.1
    StartUp(myedo)
    print("success")
    time.sleep(1.0)

    while True:
        keyboard.add_hotkey('R', on_r_key)
        target_position, gripper_state = handstate_detector.run()

        if target_position is None:
            print("No position received")
            break

        if emergancy_stop_off:
            # Perform Robot Control
            move_Robot(target_position, gripper_state)
            time.sleep(2.0)
        else:
            # Move Robot to home position
            move_Robot(Positions.home_position)
            time.sleep(2.0)
