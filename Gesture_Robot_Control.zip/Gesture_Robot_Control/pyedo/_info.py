## pyedo
## 
## @file SDK_python.py
## @author  Comau
## @version 1.0
## @date 07.11.2019
## 
## @section LICENSE
##    This  material  is the exclusive property of Comau S.p.A.  and must be
##    returned   to   Comau   S.p.A.,   Robotics  Division,  Software  Group
##    immediately   upon   request.    This  material  and  the  information
##    illustrated or contained herein may not be used, reproduced, stored in
##    a retrieval system, or transmitted in whole or in part in  any  way  -
##    electronic, mechanical, photocopying, recording, or otherwise, without
##    the prior written consent of Comau S.p.A..
## 
##                      All Rights Reserved
##                      Copyright (C)  2019
##                          Comau S.p.A.
## 
__author__ = u'Comau'
__version__ = (1, 0, 0)
